Calculate the LTV of your mobile app.
